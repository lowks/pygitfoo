========
PyGitFoo
========

:Version: 0.4.0dev
:Download: https://pypi.python.org/pypi/PyGitFoo


Git wrapper written in python.
The purpose of this tool is to provide an easy way to fetch information from git repositories.
