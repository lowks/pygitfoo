"""
This module provides python wrappers to native git comma
"""

from pygitfoo.gitinfo import GitInfo

__author__ = 'lmiranda'

git = GitInfo()
